Tourism Management System in PHP-----Installation Steps(Configuration)

1.Download and Unzip the file on your local system.
2.Copy tms folder and tms folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)

Database Configuration

Open PHPMyAdmin
Create Database tms
Import database tms.sql (available inside the zip package)
Open Your browser put inside browser “http://localhost/tms”
Login Details for admin : 

Open Your browser put inside browser “http://localhost/tms/admin”

Username: admin

Password: Test@123

Login Details for user: 

Open Your browser put inside browser “http://localhost/tms/”

Username: test@gmail.com

Password: Test@123